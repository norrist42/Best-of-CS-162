% Generate N+1 =21 equally spaced nodes xi in the interval [-5,5]
N=20;
x = linspace(-5,5,N+1);

%Evaluate f(x) at the nodes
f = inline('1./(1+x.*x)','x');
y = f(x);

%Plot the points (xi, yi) to see their location
plot(x,y,'o')
title('N+1 = 21 equally spaced data points')

%Generate points ti to evaluate f
t = [-5:0.5:5];

%Evaluate f at ti's points & plot f(t) in a new window
figure;
plot(t,f(t),'-')
title('Runge Function')

%Nth Degree Interpolating Polynomial

%Construct coefficients of Nth degree interpolating
%polynomial using equally spaced nodes
PN = polyfit(x,y,N);

%Evaluate anywhere in the interval [-5,5] at each ti
v = polyval(PN,t)

%Find the inf-norm error ||f(t)-PN(t)||?
err = norm(f(t)-v, inf)

%Plot both f(t) and PN(t) on the same plot as data points
figure;
plot(x,y,'o',t,f(t),'-',t,v,'--')
title(sprintf('f(t) and P{20}(t),err=%g',err))

%Interpolation of Chebychev Nodes:
K = N+1
a = -5;
b = 5;
xcheb = zeros(1,K);

for i=1:K
    
    xcheb(i)=(a+b)/2 +(b-a)/2*cos((i-.5)*pi/K);
    
end
    ycheb = f(xcheb)
    
%Creates Nth degree polynomial based on xcheb & ycheb
PNCheb = polyfit(xcheb, ycheb, N)

%Computes the function values at ti
vcheb = polyval(PNCheb,t)

%The inf-norm error for Chebyshev
cheb_err = norm(f(t)-vcheb,inf)

%Plot of f(t), Chebyshev Polynomial & error
figure;
plot(xcheb,ycheb,'o',t,f(t),'-',t,vcheb,'--')
title(sprintf('f(t) and Chebyshev P{20}(t), err =%g',cheb_err))

    
