// averageArea.cpp
// Timothy Norris
// CS 162 Alcorn
// 11/15/2016

double averageArea(std::vector <Shape *> &);

int main()
{
    std::vector <shape *> theShapes;
    Rectange * r = new Rectangle(5,4);
    Square * s = new Square(6);
    Circle * c = new Circle(10);

    theShapes.push_back(r);
    theShapes.push_back(s);
    theShapes.push_back(c);
    std::cout << "The average area of the three shapes is: "
    std::cout << aveageArea(theShapes) << std::endl;
}

double averageArea(std::vector <Shape *> &shapeVec)
{
    for(int i = 0; i<shapeVec.size(); i++)
    {
      double totalArea += shapeVec[i] ->Area();
    }
    double averageArea = totalArea/shapeVec.size();

    return totalArea;
}
