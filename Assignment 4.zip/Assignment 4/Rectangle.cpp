#include "Rectangle.hpp"

Rectangle::Rectangle(double l, double w)
{
    setLength(l);
    setWidth(w);
}

void setLength(double len)
{
  length = len;
}

void setWidth(double wid)
{
  width = wid;
}

~Rectangle()

virtual double Area()
{
    return length*width;
}

virtual double Perimeter()
{
    return 2*(length + width);
}
