#ifndef SHAPE_HPP
#define SHAPE_HPP

class Shape
{
    public:
            virtual double Area() = 0;
            virtual double Perimeter() = 0;
};

#endif
