#ifndef RECTANGLE_HPP
#define RECTANGLE_HPP

class Rectangle: public Shape
{
  protected:
             double length;
             double width;

  public:
            Rectangle();
            Rectangle(double l, double w);
            void setLength(double len);
            void setWidth(double wid);
            virtual double Area();
            virtual double Perimeter();
};

#endif
