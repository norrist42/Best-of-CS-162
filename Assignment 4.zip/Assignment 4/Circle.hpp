#ifndef CIRCLE_HPP
#define CIRCLE_HPP

class Circle: public Shape
{
    protected:
              double radius;

    public:
            Circle(double r);
            void setRadius(rad);
            virtual double Area();
            virtual double Perimeter();
};

#endif
