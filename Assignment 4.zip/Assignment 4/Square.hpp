#ifndef SQUARE_HPP
#define SQUARE_HPP

class Square: public Rectangle
{
    protected:
                double length;

    public:
                Square(double l): Rectangle(double l, double l);
                void setLength(double l);
                virtual double Area();
                virtual double Perimeter();
};

#endif
