#include "Circle.hpp"
#include "Shape.hpp"
#include <cstdlib>
#include <vector>

Circle::Circle(double r)
{
  setRadius(r);
}

void setRadius(rad)
{
  radius = rad;
}

virtual double Area()
{
  return 3.14*radius;
}

virtual double Perimeter()
{
  return 3.14*(2*radius);
}
