#include "square.hpp"

Square::Square(double l): Rectangle(double l, double l)
{
    setLength(l);
    setWidth(l);
}

virtual double Area();
{
  return length*length;
}

virtual double Perimeter()
{
  return  4*length;
}
